#pragma once

#define WIN32_LEAN_AND_MEAN
#define WIN32_EXTRA_LEAN

//define SETTEXTURE  65
//#define SETTEXTURESTAGESTATE  67

#include <windows.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <d3d9.h>
#include <d3dx9.h>

