# Valorant Internal Cheat

A Valorant Internal Cheat by StuzziKLL's source and given some small adjustments by me.

Picture of the menu:

![unknown](https://user-images.githubusercontent.com/66092976/133507898-5ee16496-998c-47e3-8caf-e724bdbc8b96.png)


***

#### How to use the Valorant Internal

[+] - Download it, then compile the cheat

[+] - Put both the loader.exe and the .dll in the same folder and open the loader

[+] - This will both load the driver and then after you opened Valorant, inject the .dll

***

Recommended Injector: https://www.unknowncheats.me/forum/anti-cheat-bypass/426893-injector-v2-version-eac-vanguard.html


