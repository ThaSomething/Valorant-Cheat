
#define WHITE			D3DCOLOR_ARGB(255, 255, 255, 255)//
#define RED				D3DCOLOR_ARGB(255, 255, 000, 000)//
#define GREEN			D3DCOLOR_ARGB(255, 000, 255, 000)//
#define BLUE			D3DCOLOR_ARGB(255, 000, 000, 255)//
#define BLACK			D3DCOLOR_ARGB(200, 000, 000, 000)//
#define PURPLE			D3DCOLOR_ARGB(255, 125, 000, 255)//
#define GREY			D3DCOLOR_ARGB(255, 44,44, 46)    //
#define YELLOW			D3DCOLOR_ARGB(255, 255, 255, 000)//
#define ORANGE          D3DCOLOR_ARGB(255, 255, 165, 000)//
#define DEEPSKYBLUE     D3DCOLOR_ARGB(255, 30, 144, 255) //
#define CHOCOLATE2      D3DCOLOR_ARGB(255, 238, 118, 33) //
#define GOLD2			D3DCOLOR_ARGB(255, 238, 201, 0)  //
#define SQUA			D3DCOLOR_ARGB(255, 0, 255, 255)  //
#define DARKGREY        D3DCOLOR_ARGB(255,60,60,60)      //
#define Functions       D3DCOLOR_ARGB(79,101,101,101)//
#define MenuGreen       D3DCOLOR_ARGB(255,43,119,64) //
#define MenuGREY        D3DCOLOR_ARGB(255,30,30,30)  //
#define FUCK_ON			D3DCOLOR_ARGB(254,14,159,47) //
#define FUCK_OFF		D3DCOLOR_ARGB(254,62,120,167)//
///////////////////////////////////////////////////////
#define TxtON           D3DCOLOR_ARGB(255, 000, 000, 000)
#define TxtOFF          D3DCOLOR_ARGB(120, 000, 000, 000)
#define GreenButton     D3DCOLOR_ARGB(255, 7,165, 15)
#define BorderWhite		D3DCOLOR_ARGB(255, 120,120, 120)
#define GREEN_1			D3DCOLOR_ARGB(255, 73,118,69)
#define REDD			D3DCOLOR_ARGB(255, 216,0,0)
#define DARK            D3DCOLOR_ARGB(221, 31, 31, 31)
#define DARK_Menu       D3DCOLOR_ARGB(231, 31, 31, 31)
#define Silver_Menu       D3DCOLOR_ARGB(255, 201, 201, 201)